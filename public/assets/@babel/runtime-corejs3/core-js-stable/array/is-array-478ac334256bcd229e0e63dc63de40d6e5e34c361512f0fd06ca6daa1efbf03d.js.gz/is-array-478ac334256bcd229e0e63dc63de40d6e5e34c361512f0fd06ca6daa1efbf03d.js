module.exports = require("core-js-pure/stable/array/is-array");
