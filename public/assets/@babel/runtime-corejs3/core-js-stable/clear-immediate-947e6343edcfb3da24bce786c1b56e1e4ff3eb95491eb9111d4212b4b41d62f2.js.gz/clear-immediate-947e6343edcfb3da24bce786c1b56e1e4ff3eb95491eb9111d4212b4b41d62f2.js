module.exports = require("core-js-pure/stable/clear-immediate");
