module.exports = require("core-js-pure/stable/instance/code-point-at");
