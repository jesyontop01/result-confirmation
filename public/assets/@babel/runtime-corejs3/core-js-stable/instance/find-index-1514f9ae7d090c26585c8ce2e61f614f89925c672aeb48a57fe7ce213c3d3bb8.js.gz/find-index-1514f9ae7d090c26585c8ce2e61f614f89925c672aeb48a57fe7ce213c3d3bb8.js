module.exports = require("core-js-pure/stable/instance/find-index");
