module.exports = require("core-js-pure/stable/instance/flat-map");
