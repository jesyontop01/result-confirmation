module.exports = require("core-js-pure/stable/instance/splice");
