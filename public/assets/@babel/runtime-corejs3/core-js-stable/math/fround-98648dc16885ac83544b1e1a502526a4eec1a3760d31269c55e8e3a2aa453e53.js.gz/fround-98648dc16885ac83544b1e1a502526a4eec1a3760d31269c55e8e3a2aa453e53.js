module.exports = require("core-js-pure/stable/math/fround");
