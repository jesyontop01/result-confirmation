module.exports = require("core-js-pure/stable/number/epsilon");
