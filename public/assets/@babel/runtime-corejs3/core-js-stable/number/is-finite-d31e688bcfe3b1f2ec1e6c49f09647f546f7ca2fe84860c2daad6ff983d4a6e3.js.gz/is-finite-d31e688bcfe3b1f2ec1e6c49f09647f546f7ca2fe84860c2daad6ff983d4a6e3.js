module.exports = require("core-js-pure/stable/number/is-finite");
