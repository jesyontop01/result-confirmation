module.exports = require("core-js-pure/stable/number/max-safe-integer");
