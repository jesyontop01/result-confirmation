module.exports = require("core-js-pure/stable/number/min-safe-integer");
