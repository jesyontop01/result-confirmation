module.exports = require("core-js-pure/stable/object/from-entries");
