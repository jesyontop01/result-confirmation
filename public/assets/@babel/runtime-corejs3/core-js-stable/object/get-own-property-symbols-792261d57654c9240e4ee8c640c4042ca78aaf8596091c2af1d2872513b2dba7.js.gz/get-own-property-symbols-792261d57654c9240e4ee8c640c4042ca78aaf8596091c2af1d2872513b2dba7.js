module.exports = require("core-js-pure/stable/object/get-own-property-symbols");
