module.exports = require("core-js-pure/stable/object/get-prototype-of");
