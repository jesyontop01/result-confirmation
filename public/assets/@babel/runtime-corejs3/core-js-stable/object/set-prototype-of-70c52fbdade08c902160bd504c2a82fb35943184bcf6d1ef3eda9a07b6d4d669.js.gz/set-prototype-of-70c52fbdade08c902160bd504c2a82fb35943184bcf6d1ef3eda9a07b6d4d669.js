module.exports = require("core-js-pure/stable/object/set-prototype-of");
