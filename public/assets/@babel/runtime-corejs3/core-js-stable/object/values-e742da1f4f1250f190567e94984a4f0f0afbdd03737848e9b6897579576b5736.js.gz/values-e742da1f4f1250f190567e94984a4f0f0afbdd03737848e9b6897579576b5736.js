module.exports = require("core-js-pure/stable/object/values");
