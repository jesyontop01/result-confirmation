module.exports = require("core-js-pure/stable/parse-float");
