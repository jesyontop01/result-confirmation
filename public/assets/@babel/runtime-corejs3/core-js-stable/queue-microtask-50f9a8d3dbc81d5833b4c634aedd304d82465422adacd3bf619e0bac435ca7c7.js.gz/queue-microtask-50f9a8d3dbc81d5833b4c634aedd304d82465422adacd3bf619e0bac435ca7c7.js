module.exports = require("core-js-pure/stable/queue-microtask");
