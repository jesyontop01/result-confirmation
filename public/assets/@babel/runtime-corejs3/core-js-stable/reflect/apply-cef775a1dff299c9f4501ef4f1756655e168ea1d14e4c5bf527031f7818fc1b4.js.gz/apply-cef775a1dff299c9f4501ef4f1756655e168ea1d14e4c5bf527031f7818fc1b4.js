module.exports = require("core-js-pure/stable/reflect/apply");
