module.exports = require("core-js-pure/stable/reflect/construct");
