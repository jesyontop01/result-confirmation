module.exports = require("core-js-pure/stable/reflect/delete-property");
