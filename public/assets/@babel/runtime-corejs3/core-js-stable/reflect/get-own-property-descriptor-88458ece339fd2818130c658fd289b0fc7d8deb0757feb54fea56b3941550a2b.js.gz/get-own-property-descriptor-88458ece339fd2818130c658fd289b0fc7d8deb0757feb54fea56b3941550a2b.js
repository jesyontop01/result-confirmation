module.exports = require("core-js-pure/stable/reflect/get-own-property-descriptor");
