module.exports = require("core-js-pure/stable/reflect/get-prototype-of");
