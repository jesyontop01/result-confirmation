module.exports = require("core-js-pure/stable/reflect/is-extensible");
