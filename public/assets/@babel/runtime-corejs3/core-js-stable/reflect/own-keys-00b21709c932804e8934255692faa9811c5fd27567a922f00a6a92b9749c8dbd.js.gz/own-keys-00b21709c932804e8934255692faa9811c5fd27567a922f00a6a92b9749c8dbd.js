module.exports = require("core-js-pure/stable/reflect/own-keys");
