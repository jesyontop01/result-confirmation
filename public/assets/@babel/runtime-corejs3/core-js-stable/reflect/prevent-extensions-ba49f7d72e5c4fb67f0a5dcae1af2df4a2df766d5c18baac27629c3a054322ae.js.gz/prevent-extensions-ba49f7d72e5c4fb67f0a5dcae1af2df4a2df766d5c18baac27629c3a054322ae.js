module.exports = require("core-js-pure/stable/reflect/prevent-extensions");
