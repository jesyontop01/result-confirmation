module.exports = require("core-js-pure/stable/reflect/set-prototype-of");
