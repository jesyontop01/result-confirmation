module.exports = require("core-js-pure/stable/set-interval");
