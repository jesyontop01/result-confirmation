module.exports = require("core-js-pure/stable/string/from-code-point");
