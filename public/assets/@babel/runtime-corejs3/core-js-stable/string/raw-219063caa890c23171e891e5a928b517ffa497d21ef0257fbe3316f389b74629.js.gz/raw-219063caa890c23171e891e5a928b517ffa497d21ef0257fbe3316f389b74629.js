module.exports = require("core-js-pure/stable/string/raw");
