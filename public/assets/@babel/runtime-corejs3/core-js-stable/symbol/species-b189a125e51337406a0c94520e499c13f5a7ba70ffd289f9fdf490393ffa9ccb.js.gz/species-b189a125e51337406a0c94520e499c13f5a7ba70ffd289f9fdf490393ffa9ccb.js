module.exports = require("core-js-pure/stable/symbol/species");
