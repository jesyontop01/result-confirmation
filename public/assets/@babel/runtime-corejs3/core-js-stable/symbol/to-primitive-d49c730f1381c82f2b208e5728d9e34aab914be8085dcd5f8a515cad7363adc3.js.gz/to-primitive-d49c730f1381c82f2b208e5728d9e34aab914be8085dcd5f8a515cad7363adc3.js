module.exports = require("core-js-pure/stable/symbol/to-primitive");
