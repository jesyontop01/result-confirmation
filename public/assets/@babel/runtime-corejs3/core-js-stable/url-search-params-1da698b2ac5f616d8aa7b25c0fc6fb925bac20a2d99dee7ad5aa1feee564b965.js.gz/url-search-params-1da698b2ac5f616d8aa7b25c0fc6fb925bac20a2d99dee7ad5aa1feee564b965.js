module.exports = require("core-js-pure/stable/url-search-params");
