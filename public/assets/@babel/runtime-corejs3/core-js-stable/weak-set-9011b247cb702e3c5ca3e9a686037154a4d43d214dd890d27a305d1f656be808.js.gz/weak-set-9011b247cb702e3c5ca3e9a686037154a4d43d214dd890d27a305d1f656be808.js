module.exports = require("core-js-pure/stable/weak-set");
