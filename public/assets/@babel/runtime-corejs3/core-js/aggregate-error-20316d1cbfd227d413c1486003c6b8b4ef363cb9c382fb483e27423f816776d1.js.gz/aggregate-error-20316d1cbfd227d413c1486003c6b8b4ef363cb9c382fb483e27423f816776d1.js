module.exports = require("core-js-pure/features/aggregate-error");
