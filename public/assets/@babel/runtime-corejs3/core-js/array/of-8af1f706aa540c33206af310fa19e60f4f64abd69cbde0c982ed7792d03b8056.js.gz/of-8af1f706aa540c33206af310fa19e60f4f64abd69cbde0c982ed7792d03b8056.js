module.exports = require("core-js-pure/features/array/of");
