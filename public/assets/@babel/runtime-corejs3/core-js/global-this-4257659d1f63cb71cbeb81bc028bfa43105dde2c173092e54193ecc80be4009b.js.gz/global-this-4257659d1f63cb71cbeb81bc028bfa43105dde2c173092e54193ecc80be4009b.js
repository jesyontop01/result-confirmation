module.exports = require("core-js-pure/features/global-this");
