module.exports = require("core-js-pure/features/instance/code-point-at");
