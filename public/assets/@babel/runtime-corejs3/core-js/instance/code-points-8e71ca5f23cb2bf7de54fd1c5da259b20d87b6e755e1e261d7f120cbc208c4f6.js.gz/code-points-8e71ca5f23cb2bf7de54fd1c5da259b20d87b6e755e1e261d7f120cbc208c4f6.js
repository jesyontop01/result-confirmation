module.exports = require("core-js-pure/features/instance/code-points");
