module.exports = require("core-js-pure/features/instance/every");
