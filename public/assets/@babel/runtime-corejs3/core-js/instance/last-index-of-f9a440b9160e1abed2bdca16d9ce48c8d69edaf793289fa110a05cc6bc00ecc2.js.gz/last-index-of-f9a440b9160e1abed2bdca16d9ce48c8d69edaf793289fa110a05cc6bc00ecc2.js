module.exports = require("core-js-pure/features/instance/last-index-of");
