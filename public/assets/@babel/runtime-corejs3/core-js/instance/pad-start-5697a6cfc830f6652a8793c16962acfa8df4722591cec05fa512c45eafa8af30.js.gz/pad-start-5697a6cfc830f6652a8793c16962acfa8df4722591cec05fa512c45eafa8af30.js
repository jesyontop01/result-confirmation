module.exports = require("core-js-pure/features/instance/pad-start");
