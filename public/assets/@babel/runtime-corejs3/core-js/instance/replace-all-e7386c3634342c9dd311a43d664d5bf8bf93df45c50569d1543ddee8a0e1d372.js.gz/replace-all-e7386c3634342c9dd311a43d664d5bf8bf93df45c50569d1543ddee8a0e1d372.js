module.exports = require("core-js-pure/features/instance/replace-all");
