module.exports = require("core-js-pure/features/is-iterable");
