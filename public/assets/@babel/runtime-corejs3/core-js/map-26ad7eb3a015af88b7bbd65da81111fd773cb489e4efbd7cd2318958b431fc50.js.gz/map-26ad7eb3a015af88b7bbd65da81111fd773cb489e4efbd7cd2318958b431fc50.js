module.exports = require("core-js-pure/features/map");
