module.exports = require("core-js-pure/features/math/deg-per-rad");
