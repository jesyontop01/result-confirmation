module.exports = require("core-js-pure/features/math/expm1");
