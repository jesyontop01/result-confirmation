module.exports = require("core-js-pure/features/math/log10");
