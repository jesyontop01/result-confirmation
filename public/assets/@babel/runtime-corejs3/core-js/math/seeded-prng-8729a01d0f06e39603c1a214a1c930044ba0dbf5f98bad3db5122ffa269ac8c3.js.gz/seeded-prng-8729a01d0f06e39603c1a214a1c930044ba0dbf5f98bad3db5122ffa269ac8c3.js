module.exports = require("core-js-pure/features/math/seeded-prng");
