module.exports = require("core-js-pure/features/number/is-integer");
