module.exports = require("core-js-pure/features/number/is-safe-integer");
