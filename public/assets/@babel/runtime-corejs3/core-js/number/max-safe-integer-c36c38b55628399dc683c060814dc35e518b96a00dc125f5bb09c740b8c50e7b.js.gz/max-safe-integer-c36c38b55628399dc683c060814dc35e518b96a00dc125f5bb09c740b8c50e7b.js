module.exports = require("core-js-pure/features/number/max-safe-integer");
