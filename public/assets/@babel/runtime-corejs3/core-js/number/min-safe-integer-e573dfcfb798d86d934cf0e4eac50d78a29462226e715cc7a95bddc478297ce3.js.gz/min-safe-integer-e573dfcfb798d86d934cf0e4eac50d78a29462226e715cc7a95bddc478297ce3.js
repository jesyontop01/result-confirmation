module.exports = require("core-js-pure/features/number/min-safe-integer");
