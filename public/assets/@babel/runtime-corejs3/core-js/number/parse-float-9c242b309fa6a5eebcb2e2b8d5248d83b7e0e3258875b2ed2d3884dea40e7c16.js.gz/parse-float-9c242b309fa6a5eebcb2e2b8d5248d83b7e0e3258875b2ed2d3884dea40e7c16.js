module.exports = require("core-js-pure/features/number/parse-float");
