module.exports = require("core-js-pure/features/object/define-properties");
