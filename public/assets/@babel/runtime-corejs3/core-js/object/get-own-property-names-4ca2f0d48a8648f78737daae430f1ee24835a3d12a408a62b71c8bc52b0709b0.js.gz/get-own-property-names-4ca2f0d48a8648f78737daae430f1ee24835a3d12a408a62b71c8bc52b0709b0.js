module.exports = require("core-js-pure/features/object/get-own-property-names");
