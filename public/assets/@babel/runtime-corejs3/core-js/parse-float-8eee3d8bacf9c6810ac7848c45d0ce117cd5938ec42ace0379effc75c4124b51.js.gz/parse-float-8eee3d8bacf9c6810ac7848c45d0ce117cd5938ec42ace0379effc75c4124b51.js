module.exports = require("core-js-pure/features/parse-float");
