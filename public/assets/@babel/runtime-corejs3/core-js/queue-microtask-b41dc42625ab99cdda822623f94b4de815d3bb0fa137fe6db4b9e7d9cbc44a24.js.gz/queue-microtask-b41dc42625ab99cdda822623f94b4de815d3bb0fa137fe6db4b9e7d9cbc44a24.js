module.exports = require("core-js-pure/features/queue-microtask");
