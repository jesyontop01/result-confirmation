module.exports = require("core-js-pure/features/reflect/get-own-metadata-keys");
