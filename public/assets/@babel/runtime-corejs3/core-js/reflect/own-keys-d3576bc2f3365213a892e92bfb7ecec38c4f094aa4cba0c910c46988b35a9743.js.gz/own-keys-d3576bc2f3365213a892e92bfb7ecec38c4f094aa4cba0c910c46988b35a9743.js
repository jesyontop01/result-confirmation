module.exports = require("core-js-pure/features/reflect/own-keys");
