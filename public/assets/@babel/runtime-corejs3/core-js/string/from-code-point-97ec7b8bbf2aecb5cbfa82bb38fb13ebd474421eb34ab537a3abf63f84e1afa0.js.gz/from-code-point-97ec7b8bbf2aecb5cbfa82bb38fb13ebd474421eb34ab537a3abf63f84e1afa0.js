module.exports = require("core-js-pure/features/string/from-code-point");
