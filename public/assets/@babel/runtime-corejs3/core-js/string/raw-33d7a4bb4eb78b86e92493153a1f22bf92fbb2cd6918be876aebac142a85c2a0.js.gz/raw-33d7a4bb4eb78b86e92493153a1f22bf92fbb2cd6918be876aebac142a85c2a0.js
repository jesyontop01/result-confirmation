module.exports = require("core-js-pure/features/string/raw");
