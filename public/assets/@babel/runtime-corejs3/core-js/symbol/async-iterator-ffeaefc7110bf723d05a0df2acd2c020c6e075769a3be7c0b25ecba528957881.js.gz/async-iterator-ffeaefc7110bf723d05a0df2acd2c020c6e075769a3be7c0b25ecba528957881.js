module.exports = require("core-js-pure/features/symbol/async-iterator");
