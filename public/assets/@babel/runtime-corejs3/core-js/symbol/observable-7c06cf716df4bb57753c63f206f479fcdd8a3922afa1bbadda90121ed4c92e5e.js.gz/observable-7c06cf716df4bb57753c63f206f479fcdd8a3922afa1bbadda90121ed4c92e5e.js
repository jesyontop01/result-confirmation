module.exports = require("core-js-pure/features/symbol/observable");
