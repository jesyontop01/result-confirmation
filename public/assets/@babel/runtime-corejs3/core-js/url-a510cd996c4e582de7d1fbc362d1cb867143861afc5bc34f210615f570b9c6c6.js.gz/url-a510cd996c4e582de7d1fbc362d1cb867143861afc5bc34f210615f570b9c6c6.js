module.exports = require("core-js-pure/features/url");
