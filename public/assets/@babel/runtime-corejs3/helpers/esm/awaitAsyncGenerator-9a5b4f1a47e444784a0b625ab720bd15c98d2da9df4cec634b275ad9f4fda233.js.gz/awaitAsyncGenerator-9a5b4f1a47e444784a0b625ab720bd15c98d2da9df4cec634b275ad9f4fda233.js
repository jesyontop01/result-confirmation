import AwaitValue from "./AwaitValue.js";
export default function _awaitAsyncGenerator(value) {
  return new AwaitValue(value);
}
;
