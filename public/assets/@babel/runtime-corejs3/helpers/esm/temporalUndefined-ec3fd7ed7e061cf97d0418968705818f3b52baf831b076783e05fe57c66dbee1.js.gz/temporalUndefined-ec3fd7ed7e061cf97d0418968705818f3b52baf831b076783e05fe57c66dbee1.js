export default function _temporalUndefined() {}
;
