(function() {

QUnit.module('DOM');

})();
