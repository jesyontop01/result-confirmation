require('./src/angular-base64-upload.js');
module.exports = 'naif.base64';
