require('./angular-cookie');
module.exports = 'ipCookie';
