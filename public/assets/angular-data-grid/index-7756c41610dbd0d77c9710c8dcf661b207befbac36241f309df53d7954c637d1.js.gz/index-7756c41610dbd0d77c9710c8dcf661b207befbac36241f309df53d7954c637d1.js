require('./dist/dataGrid');
require('./dist/pagination');

module.exports = {
    dataGrid: 'dataGrid',
    pagination: 'pagination',
};
