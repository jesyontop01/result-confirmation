var devise = angular.module('Devise', []);
