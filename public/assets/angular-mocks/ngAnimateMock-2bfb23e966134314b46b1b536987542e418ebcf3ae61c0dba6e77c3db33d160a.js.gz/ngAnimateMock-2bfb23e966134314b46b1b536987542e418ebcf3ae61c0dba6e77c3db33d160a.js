require('./angular-mocks');
module.exports = 'ngAnimateMock';
