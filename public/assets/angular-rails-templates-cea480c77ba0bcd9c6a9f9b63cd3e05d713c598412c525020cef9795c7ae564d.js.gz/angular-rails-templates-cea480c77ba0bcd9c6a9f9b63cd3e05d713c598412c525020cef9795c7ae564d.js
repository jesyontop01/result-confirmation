// Angular Rails Templates 1.1.0
//
// angular_templates.ignore_prefix: ["templates/"]
// angular_templates.markups: ["erb", "haml", "str"]
// angular_templates.htmlcompressor: 

angular.module("templates", []);

