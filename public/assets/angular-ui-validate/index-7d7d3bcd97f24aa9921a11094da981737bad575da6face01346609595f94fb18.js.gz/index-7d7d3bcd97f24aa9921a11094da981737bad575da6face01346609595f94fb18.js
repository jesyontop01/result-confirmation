require('./dist/validate');
module.exports = 'ui.validate';
