export default {
  "files": [
    "test/node.test.js",
    "test/browser.test.js"
  ],
  "compileEnhancements": true
};
