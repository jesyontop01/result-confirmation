angular.module('verifier')
.controller('HomeCtrl', function ($scope, $rootScope, Auth) {
	// body...
	$scope.hello = 'Hello World';
} )
;
