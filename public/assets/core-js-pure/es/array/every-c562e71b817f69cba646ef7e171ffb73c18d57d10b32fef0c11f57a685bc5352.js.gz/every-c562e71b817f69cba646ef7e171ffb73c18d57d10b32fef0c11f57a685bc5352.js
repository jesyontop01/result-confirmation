require('../../modules/es.array.every');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Array', 'every');
