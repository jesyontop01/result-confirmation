require('../../modules/es.array.join');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Array', 'join');
