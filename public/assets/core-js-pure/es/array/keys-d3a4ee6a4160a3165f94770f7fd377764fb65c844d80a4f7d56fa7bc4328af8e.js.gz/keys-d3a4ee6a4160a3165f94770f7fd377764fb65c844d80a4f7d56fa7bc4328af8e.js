require('../../modules/es.array.iterator');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Array', 'keys');
