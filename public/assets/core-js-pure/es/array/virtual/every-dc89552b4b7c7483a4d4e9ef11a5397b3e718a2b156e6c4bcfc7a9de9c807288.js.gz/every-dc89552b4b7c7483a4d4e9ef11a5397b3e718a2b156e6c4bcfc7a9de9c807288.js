require('../../../modules/es.array.every');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('Array').every;
