require('../../../modules/es.array.reverse');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('Array').reverse;
