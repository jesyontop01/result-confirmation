require('../../modules/es.math.fround');
var path = require('../../internals/path');

module.exports = path.Math.fround;
