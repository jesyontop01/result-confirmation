require('../../modules/es.math.log2');
var path = require('../../internals/path');

module.exports = path.Math.log2;
