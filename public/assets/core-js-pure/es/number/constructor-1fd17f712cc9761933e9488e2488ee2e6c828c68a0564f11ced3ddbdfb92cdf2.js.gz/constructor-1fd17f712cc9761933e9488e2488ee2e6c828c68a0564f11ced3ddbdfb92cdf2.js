require('../../modules/es.number.constructor');

module.exports = Number;
