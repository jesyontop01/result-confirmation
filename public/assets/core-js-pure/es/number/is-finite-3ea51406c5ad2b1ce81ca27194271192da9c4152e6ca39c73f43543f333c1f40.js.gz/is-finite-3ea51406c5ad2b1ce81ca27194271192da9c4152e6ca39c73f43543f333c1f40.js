require('../../modules/es.number.is-finite');
var path = require('../../internals/path');

module.exports = path.Number.isFinite;
