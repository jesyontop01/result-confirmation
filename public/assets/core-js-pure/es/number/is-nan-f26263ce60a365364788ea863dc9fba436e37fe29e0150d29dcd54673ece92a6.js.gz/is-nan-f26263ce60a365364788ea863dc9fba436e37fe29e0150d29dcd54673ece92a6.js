require('../../modules/es.number.is-nan');
var path = require('../../internals/path');

module.exports = path.Number.isNaN;
