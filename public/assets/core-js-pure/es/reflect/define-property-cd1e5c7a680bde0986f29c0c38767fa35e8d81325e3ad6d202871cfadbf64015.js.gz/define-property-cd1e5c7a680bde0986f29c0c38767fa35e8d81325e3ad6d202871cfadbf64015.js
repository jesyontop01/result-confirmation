require('../../modules/es.reflect.define-property');
var path = require('../../internals/path');

module.exports = path.Reflect.defineProperty;
