require('../../modules/es.reflect.get');
var path = require('../../internals/path');

module.exports = path.Reflect.get;
