require('../../modules/es.reflect.get-own-property-descriptor');
var path = require('../../internals/path');

module.exports = path.Reflect.getOwnPropertyDescriptor;
