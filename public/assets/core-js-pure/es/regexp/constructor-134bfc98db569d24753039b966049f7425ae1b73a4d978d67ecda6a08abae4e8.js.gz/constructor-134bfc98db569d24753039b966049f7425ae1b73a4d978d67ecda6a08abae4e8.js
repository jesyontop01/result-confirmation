require('../../modules/es.regexp.constructor');

module.exports = RegExp;
