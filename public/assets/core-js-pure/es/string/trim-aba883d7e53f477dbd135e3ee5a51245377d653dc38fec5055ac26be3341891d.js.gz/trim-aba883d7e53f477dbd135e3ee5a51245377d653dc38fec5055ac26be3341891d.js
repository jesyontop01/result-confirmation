require('../../modules/es.string.trim');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('String', 'trim');
