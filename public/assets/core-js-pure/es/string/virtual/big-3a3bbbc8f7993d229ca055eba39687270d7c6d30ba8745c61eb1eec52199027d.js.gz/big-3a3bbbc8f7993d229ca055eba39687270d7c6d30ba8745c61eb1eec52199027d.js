require('../../../modules/es.string.big');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('String').big;
