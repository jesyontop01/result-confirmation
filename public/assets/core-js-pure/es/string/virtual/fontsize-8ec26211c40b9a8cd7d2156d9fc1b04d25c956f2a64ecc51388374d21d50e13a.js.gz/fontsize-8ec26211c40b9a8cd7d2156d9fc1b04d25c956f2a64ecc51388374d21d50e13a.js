require('../../../modules/es.string.fontsize');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('String').fontsize;
