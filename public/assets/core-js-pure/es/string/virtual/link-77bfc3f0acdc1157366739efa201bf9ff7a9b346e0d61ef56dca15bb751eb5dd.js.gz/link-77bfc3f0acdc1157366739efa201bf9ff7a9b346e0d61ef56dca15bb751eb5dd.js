require('../../../modules/es.string.link');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('String').link;
