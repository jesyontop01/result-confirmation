require('../../modules/es.symbol.is-concat-spreadable');
require('../../modules/es.array.concat');
var WrappedWellKnownSymbolModule = require('../../internals/well-known-symbol-wrapped');

module.exports = WrappedWellKnownSymbolModule.f('isConcatSpreadable');
