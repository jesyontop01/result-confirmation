require('../../modules/es.symbol.match');
require('../../modules/es.string.match');
var WrappedWellKnownSymbolModule = require('../../internals/well-known-symbol-wrapped');

module.exports = WrappedWellKnownSymbolModule.f('match');
