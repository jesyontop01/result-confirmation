require('../../modules/es.typed-array.last-index-of');
