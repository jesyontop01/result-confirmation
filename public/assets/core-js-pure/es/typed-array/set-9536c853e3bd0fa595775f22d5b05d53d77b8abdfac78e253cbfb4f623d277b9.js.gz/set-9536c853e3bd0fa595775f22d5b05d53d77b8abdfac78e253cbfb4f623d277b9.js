require('../../modules/es.typed-array.set');
