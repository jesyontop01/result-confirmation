require('../../modules/es.object.to-string');
require('../../modules/es.weak-set');
require('../../modules/web.dom-collections.iterator');
var path = require('../../internals/path');

module.exports = path.WeakSet;
