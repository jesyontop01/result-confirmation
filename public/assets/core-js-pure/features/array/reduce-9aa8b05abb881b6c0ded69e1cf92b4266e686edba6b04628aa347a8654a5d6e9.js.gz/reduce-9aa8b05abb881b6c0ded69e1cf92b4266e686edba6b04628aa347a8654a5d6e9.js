var parent = require('../../es/array/reduce');

module.exports = parent;
