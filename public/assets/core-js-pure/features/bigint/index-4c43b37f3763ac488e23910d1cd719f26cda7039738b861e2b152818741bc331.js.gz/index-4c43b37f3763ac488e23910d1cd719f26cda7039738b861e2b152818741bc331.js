require('../../modules/esnext.bigint.range');
var BigInt = require('../../internals/path').BigInt;

module.exports = BigInt;
