var parent = require('../../../es/function/virtual');

module.exports = parent;
