var parent = require('../../es/instance/trim-start');

module.exports = parent;
