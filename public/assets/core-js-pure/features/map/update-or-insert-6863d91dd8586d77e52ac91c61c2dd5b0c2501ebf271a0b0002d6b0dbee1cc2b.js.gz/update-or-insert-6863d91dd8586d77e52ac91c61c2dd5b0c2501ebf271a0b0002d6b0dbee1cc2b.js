// TODO: remove from `core-js@4`
require('../../modules/es.map');
require('../../modules/esnext.map.update-or-insert');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Map', 'updateOrInsert');
