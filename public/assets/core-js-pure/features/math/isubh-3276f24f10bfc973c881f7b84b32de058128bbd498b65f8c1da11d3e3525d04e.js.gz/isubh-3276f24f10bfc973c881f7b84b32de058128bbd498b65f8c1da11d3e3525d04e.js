require('../../modules/esnext.math.isubh');
var path = require('../../internals/path');

module.exports = path.Math.isubh;
