var parent = require('../../es/number/constructor');

module.exports = parent;
