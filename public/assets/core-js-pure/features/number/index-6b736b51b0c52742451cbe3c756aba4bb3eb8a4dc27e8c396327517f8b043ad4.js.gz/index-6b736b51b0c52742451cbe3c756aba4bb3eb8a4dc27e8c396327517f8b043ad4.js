var parent = require('../../es/number');

module.exports = parent;

require('../../modules/esnext.number.from-string');
require('../../modules/esnext.number.range');
