var parent = require('../../es/number/parse-float');

module.exports = parent;
