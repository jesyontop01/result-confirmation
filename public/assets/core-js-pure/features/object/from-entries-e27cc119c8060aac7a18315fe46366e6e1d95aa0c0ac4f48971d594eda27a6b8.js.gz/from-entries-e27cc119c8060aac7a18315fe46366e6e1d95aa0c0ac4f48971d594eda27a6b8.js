var parent = require('../../es/object/from-entries');

module.exports = parent;
