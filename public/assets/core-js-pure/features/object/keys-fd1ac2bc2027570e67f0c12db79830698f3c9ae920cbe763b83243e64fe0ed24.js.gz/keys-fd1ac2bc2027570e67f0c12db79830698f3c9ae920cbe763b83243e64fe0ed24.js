var parent = require('../../es/object/keys');

module.exports = parent;
