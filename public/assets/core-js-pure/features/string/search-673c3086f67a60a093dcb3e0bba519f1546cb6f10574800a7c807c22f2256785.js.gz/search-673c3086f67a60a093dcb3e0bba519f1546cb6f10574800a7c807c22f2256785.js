var parent = require('../../es/string/search');

module.exports = parent;
