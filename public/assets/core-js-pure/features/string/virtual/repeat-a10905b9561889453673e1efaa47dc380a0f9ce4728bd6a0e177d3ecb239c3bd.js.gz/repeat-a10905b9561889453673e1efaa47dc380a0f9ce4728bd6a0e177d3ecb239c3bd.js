var parent = require('../../../es/string/virtual/repeat');

module.exports = parent;
