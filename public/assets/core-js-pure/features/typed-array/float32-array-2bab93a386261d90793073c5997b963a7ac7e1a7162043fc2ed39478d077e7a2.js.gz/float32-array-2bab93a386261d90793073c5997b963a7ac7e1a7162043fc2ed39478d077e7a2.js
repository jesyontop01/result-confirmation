var parent = require('../../es/typed-array/float32-array');

module.exports = parent;
