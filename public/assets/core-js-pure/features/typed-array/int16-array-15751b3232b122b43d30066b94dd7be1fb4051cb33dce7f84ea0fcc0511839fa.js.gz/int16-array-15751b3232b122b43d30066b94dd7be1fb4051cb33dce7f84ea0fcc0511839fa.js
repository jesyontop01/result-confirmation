var parent = require('../../es/typed-array/int16-array');

module.exports = parent;
