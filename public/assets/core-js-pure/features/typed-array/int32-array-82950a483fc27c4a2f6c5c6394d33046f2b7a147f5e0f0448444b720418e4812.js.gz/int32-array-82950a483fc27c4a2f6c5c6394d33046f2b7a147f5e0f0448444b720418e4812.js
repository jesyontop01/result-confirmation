var parent = require('../../es/typed-array/int32-array');

module.exports = parent;
