require('../../modules/es.typed-array.join');
