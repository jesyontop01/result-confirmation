require('../../modules/es.weak-map');
require('../../modules/esnext.weak-map.emplace');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('WeakMap', 'emplace');
