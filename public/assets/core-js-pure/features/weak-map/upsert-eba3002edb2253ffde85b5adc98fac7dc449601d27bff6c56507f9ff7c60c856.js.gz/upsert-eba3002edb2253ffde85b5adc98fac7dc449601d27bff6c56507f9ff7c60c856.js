require('../../modules/es.weak-map');
require('../../modules/esnext.weak-map.upsert');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('WeakMap', 'upsert');
