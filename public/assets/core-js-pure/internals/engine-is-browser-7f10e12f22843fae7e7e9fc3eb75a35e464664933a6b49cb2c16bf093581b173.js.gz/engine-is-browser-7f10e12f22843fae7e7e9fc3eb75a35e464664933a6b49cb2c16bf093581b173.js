module.exports = typeof window == 'object';
