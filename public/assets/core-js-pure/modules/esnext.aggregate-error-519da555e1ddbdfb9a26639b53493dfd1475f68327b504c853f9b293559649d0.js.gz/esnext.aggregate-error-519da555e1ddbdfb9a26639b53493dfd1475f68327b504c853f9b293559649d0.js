// TODO: Remove from `core-js@4`
require('./es.aggregate-error');
