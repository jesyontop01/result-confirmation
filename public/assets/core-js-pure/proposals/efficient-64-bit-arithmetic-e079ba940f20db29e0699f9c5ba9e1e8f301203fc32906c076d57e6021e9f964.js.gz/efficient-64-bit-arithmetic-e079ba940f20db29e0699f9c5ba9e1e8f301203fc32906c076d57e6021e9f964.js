// TODO: remove from `core-js@4` as withdrawn
require('../modules/esnext.math.iaddh');
require('../modules/esnext.math.isubh');
require('../modules/esnext.math.imulh');
require('../modules/esnext.math.umulh');
