require('../modules/esnext.global-this');
var global = require('../internals/global');

module.exports = global;
