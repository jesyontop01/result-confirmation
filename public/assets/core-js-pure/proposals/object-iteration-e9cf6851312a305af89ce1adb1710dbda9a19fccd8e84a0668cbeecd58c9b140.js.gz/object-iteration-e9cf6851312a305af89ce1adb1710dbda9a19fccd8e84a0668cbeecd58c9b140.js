// TODO: remove from `core-js@4` as withdrawn
require('../modules/esnext.object.iterate-entries');
require('../modules/esnext.object.iterate-keys');
require('../modules/esnext.object.iterate-values');
