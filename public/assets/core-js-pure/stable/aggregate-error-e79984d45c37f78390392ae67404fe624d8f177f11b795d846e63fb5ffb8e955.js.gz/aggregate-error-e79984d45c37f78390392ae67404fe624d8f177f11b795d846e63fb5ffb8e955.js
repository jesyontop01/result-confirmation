// TODO: remove from `core-js@4`
require('../modules/esnext.aggregate-error');

var parent = require('../es/aggregate-error');

module.exports = parent;
