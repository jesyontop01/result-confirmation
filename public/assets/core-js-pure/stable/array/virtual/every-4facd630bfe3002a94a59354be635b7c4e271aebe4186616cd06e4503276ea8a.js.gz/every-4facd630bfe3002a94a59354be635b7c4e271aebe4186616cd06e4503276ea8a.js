var parent = require('../../../es/array/virtual/every');

module.exports = parent;
