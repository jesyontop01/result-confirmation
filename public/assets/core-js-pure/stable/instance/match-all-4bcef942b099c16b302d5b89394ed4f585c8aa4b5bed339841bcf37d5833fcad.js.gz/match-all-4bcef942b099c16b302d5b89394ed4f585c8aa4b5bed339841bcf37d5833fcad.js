var parent = require('../../es/instance/match-all');

module.exports = parent;
