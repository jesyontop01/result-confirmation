var parent = require('../../es/object');

module.exports = parent;
