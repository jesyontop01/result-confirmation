var parent = require('../../es/promise');

module.exports = parent;
