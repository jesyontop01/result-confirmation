var parent = require('../web/queue-microtask');

module.exports = parent;
