var parent = require('../../es/string');

module.exports = parent;
