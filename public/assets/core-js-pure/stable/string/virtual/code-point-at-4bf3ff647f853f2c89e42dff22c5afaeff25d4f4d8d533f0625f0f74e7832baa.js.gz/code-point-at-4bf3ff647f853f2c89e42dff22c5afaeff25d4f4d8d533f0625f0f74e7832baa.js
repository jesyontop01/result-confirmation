var parent = require('../../../es/string/virtual/code-point-at');

module.exports = parent;
