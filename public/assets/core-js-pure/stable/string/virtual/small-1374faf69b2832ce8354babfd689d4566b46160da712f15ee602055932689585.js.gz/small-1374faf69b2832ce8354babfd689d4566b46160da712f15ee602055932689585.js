var parent = require('../../../es/string/virtual/small');

module.exports = parent;
