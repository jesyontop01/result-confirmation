var parent = require('../../es/symbol/async-iterator');

module.exports = parent;
