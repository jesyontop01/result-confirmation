var parent = require('../../es/symbol/to-primitive');

module.exports = parent;
