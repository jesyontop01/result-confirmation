var parent = require('../../es/typed-array/uint32-array');

module.exports = parent;
