var parent = require('../../es/typed-array/uint8-array');

module.exports = parent;
