var parent = require('../../es/weak-map');

module.exports = parent;
