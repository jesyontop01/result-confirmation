require('../modules/web.url-search-params');
var path = require('../internals/path');

module.exports = path.URLSearchParams;
