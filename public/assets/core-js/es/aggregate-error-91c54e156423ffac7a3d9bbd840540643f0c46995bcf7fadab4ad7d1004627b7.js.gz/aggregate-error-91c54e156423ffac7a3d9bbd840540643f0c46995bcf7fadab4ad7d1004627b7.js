require('../modules/es.aggregate-error');
require('../modules/es.string.iterator');
require('../modules/web.dom-collections.iterator');
var path = require('../internals/path');

module.exports = path.AggregateError;
