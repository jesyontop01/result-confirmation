require('../../modules/es.array-buffer.constructor');
require('../../modules/es.object.to-string');
var path = require('../../internals/path');

module.exports = path.ArrayBuffer;
