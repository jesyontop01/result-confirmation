require('../../../modules/es.array.copy-within');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('Array').copyWithin;
