require('../../../modules/es.array.reduce-right');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('Array').reduceRight;
