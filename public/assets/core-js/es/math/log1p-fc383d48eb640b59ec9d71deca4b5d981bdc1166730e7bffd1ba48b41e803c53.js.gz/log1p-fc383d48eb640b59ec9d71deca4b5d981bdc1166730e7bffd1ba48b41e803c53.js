require('../../modules/es.math.log1p');
var path = require('../../internals/path');

module.exports = path.Math.log1p;
