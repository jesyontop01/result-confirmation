require('../../modules/es.math.sign');
var path = require('../../internals/path');

module.exports = path.Math.sign;
