require('../../modules/es.object.is');
var path = require('../../internals/path');

module.exports = path.Object.is;
