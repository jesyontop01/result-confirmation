require('../../modules/es.object.is-frozen');
var path = require('../../internals/path');

module.exports = path.Object.isFrozen;
