require('../../modules/es.reflect.is-extensible');
var path = require('../../internals/path');

module.exports = path.Reflect.isExtensible;
