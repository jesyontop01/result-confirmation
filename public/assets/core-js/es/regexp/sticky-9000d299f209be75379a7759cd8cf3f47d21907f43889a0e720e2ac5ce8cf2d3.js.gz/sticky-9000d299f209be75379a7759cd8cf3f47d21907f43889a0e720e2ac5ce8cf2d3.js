require('../../modules/es.regexp.sticky');

module.exports = function (it) {
  return it.sticky;
};
