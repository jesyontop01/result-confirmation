require('../../modules/es.string.blink');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('String', 'blink');
