require('../../modules/es.string.replace-all');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('String', 'replaceAll');
