require('../../../modules/es.string.ends-with');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('String').endsWith;
