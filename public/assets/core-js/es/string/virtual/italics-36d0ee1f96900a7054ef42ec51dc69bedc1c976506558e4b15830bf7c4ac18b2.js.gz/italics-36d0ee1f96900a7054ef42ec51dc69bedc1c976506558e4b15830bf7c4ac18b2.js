require('../../../modules/es.string.italics');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('String').italics;
