require('../../../modules/es.string.match-all');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('String').matchAll;
