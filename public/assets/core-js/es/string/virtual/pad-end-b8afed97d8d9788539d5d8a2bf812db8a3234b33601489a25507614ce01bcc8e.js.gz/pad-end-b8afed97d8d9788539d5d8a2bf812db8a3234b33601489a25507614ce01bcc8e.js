require('../../../modules/es.string.pad-end');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('String').padEnd;
