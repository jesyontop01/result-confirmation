require('../../modules/es.symbol.search');
require('../../modules/es.string.search');
var WrappedWellKnownSymbolModule = require('../../internals/well-known-symbol-wrapped');

module.exports = WrappedWellKnownSymbolModule.f('search');
