require('../../modules/es.typed-array.int8-array');
require('./methods');
var global = require('../../internals/global');

module.exports = global.Int8Array;
