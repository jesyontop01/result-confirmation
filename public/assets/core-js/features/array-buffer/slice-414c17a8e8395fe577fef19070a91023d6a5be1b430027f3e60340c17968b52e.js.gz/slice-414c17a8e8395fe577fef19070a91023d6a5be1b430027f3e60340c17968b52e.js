var parent = require('../../es/array-buffer/slice');

module.exports = parent;
