require('../../modules/esnext.object.has-own');
var path = require('../../internals/path');

module.exports = path.Object.hasOwn;
