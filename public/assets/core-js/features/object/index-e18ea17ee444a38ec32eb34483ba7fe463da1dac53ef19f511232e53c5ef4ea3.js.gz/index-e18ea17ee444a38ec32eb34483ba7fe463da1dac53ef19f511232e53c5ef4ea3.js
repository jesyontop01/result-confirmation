var parent = require('../../es/object');
require('../../modules/esnext.object.has-own');
require('../../modules/esnext.object.iterate-entries');
require('../../modules/esnext.object.iterate-keys');
require('../../modules/esnext.object.iterate-values');

module.exports = parent;
