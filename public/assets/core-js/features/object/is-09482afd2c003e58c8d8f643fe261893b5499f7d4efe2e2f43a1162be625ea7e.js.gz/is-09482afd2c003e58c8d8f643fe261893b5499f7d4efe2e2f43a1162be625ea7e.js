var parent = require('../../es/object/is');

module.exports = parent;
