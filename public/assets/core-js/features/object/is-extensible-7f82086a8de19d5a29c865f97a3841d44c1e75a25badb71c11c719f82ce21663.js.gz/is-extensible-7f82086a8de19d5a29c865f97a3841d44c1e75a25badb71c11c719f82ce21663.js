var parent = require('../../es/object/is-extensible');

module.exports = parent;
