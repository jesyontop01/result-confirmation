var parent = require('../../es/reflect/define-property');

module.exports = parent;
