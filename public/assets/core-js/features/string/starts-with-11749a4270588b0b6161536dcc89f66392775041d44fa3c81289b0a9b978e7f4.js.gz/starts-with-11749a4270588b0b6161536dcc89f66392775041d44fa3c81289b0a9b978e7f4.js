var parent = require('../../es/string/starts-with');

module.exports = parent;
