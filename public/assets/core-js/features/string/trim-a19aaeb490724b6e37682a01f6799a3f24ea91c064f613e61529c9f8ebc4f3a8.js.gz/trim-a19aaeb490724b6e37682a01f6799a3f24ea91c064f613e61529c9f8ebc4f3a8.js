var parent = require('../../es/string/trim');

module.exports = parent;
