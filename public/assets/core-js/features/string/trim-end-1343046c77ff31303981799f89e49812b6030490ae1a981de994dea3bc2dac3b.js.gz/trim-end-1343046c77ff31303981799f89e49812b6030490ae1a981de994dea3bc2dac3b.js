var parent = require('../../es/string/trim-end');

module.exports = parent;
