var parent = require('../../es/string/trim-start');

module.exports = parent;
