var parent = require('../../../es/string/virtual/link');

module.exports = parent;
