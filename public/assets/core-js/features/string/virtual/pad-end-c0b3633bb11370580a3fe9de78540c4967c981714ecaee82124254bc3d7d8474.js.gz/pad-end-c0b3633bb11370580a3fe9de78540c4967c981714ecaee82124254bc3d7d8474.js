var parent = require('../../../es/string/virtual/pad-end');

module.exports = parent;
