var parent = require('../../../es/string/virtual/trim');

module.exports = parent;
