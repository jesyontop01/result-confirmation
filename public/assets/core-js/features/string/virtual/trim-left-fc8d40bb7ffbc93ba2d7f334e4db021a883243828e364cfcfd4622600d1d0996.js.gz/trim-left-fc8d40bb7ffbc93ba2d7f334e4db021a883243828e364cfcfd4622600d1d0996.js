var parent = require('../../../es/string/virtual/trim-left');

module.exports = parent;
