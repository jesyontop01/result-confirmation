var parent = require('../../es/typed-array/int8-array');

module.exports = parent;
