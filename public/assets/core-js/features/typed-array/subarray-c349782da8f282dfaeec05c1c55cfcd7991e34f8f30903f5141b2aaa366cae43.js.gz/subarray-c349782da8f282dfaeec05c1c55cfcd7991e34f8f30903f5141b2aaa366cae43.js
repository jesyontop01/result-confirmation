require('../../modules/es.typed-array.subarray');
