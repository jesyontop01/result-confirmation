var parent = require('../../stable/url/to-json');

module.exports = parent;
