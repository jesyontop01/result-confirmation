// TODO: Remove from `core-js@4`
require('./es.promise.all-settled.js');
