require('../modules/esnext.map.from');
require('../modules/esnext.map.of');
require('../modules/esnext.set.from');
require('../modules/esnext.set.of');
require('../modules/esnext.weak-map.from');
require('../modules/esnext.weak-map.of');
require('../modules/esnext.weak-set.from');
require('../modules/esnext.weak-set.of');
