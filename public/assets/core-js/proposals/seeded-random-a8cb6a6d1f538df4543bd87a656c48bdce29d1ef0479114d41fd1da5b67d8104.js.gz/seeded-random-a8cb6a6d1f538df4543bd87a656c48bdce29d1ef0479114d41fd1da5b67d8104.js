require('../modules/esnext.math.seeded-prng');
