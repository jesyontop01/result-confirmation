require('../modules/esnext.string.replace-all');
require('../modules/esnext.symbol.replace-all');
