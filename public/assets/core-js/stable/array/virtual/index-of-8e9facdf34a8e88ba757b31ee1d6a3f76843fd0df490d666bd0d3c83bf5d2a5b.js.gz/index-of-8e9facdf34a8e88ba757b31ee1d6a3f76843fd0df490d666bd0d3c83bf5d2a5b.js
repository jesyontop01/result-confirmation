var parent = require('../../../es/array/virtual/index-of');

module.exports = parent;
