var parent = require('../../../es/array/virtual/iterator');

module.exports = parent;
