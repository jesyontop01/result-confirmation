var parent = require('../../../es/array/virtual/some');

module.exports = parent;
