var parent = require('../../../es/array/virtual/splice');

module.exports = parent;
