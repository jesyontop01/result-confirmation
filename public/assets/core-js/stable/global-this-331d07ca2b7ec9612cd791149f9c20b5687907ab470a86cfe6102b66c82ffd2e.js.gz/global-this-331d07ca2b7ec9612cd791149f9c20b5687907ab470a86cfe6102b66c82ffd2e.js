var parent = require('../es/global-this');

module.exports = parent;
