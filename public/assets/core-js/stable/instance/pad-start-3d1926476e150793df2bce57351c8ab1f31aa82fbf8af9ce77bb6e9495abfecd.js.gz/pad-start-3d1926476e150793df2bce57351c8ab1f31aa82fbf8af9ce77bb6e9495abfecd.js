var parent = require('../../es/instance/pad-start');

module.exports = parent;
