var parent = require('../../es/json/stringify');

module.exports = parent;
