var parent = require('../../es/map');

module.exports = parent;
