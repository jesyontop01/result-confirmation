var parent = require('../../es/math/clz32');

module.exports = parent;
