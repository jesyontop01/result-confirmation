var parent = require('../../es/math/trunc');

module.exports = parent;
