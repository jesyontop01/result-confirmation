var parent = require('../../es/object/create');

module.exports = parent;
