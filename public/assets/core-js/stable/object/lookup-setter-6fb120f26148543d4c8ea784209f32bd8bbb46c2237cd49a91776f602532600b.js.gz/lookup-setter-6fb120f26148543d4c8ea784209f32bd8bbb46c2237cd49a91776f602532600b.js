var parent = require('../../es/object/lookup-setter');

module.exports = parent;
