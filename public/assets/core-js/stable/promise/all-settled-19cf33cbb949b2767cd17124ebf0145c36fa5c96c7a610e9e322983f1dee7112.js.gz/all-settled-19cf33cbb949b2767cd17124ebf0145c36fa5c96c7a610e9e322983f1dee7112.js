var parent = require('../../es/promise/all-settled');

module.exports = parent;
