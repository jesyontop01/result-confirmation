var parent = require('../../es/promise/any');

module.exports = parent;
