var parent = require('../../es/reflect/prevent-extensions');

module.exports = parent;
