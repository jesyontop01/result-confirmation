var parent = require('../../es/string/from-code-point');

module.exports = parent;
