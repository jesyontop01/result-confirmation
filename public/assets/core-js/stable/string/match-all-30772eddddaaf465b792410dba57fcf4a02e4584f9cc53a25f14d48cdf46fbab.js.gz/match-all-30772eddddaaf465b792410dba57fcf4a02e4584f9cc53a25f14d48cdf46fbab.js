var parent = require('../../es/string/match-all');

module.exports = parent;
