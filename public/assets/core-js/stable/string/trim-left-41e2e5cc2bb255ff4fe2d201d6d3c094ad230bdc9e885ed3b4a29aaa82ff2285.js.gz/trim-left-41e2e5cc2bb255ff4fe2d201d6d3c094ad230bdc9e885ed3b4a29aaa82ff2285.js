var parent = require('../../es/string/trim-left');

module.exports = parent;
