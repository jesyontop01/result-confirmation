var parent = require('../../../es/string/virtual/ends-with');

module.exports = parent;
