var parent = require('../../es/symbol/for');

module.exports = parent;
