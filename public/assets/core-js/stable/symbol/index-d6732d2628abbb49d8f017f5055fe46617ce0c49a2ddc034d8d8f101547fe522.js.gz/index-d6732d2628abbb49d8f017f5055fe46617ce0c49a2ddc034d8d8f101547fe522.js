var parent = require('../../es/symbol');

module.exports = parent;
