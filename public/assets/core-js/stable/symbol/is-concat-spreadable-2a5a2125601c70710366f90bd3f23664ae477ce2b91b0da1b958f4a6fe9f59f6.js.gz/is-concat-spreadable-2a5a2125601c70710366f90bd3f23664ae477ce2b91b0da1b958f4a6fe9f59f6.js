var parent = require('../../es/symbol/is-concat-spreadable');

module.exports = parent;
