var parent = require('../../es/symbol/iterator');

module.exports = parent;
