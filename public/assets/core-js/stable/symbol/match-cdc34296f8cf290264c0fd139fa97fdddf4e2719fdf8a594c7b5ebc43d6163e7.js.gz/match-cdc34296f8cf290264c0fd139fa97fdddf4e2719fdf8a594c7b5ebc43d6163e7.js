var parent = require('../../es/symbol/match');

module.exports = parent;
