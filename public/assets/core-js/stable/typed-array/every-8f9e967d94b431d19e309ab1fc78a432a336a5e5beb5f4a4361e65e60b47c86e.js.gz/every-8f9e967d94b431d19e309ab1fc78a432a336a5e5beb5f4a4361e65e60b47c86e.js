require('../../modules/es.typed-array.every');
