var parent = require('../../es/typed-array/float64-array');

module.exports = parent;
