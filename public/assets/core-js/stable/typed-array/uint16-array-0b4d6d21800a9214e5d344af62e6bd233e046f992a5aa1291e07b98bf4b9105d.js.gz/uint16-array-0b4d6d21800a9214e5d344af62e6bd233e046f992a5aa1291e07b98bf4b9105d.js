var parent = require('../../es/typed-array/uint16-array');

module.exports = parent;
