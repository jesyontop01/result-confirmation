var parent = require('../../web/url-search-params');

module.exports = parent;
