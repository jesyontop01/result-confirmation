var parent = require('../../es/weak-set');

module.exports = parent;
