require('../proposals/relative-indexing-method');
var parent = require('./4');

module.exports = parent;
