require('../proposals/reflect-metadata');
var parent = require('./0');

module.exports = parent;
