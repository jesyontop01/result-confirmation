require('../modules/web.dom-collections.for-each');
require('../modules/web.dom-collections.iterator');
var path = require('../internals/path');

module.exports = path;
