require('../modules/web.queue-microtask');
var path = require('../internals/path');

module.exports = path.queueMicrotask;
