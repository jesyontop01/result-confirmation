"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Util_1 = require("./Util");
exports.toCodePoints = Util_1.toCodePoints;
exports.fromCodePoint = Util_1.fromCodePoint;
var LineBreak_1 = require("./LineBreak");
exports.LineBreaker = LineBreak_1.LineBreaker;
//# sourceMappingURL=/assets/css-line-break/dist/lib/index.js-ba2ba340f958051181510c5b59a7ca1ebe84d7a55ef152bfbe9b7bfafc7f0650.map
//!

;
