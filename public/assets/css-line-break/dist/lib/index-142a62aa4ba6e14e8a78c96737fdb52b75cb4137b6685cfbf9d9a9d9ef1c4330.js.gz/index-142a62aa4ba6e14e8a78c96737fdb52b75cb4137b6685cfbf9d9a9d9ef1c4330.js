"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Util_1 = require("./Util");
exports.toCodePoints = Util_1.toCodePoints;
exports.fromCodePoint = Util_1.fromCodePoint;
var LineBreak_1 = require("./LineBreak");
exports.LineBreaker = LineBreak_1.LineBreaker;
//# sourceMappingURL=index.js.map
;
