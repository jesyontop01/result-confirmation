"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FEATURES = {
    SUPPORT_RANGE_BOUNDS: true,
    SUPPORT_SVG_DRAWING: true,
    SUPPORT_FOREIGNOBJECT_DRAWING: true,
    SUPPORT_CORS_IMAGES: true,
    SUPPORT_RESPONSE_TYPE: true,
    SUPPORT_CORS_XHR: true
};
//# sourceMappingURL=/assets/html2canvas/dist/lib/core/__mocks__/features.js-256a29eee0deb3ed7ca7ec8120b5a31ee9274eb4e180a4dbeced55916f78e080.map
//!

;
