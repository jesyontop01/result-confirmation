"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FEATURES = {
    SUPPORT_RANGE_BOUNDS: true,
    SUPPORT_SVG_DRAWING: true,
    SUPPORT_FOREIGNOBJECT_DRAWING: true,
    SUPPORT_CORS_IMAGES: true,
    SUPPORT_RESPONSE_TYPE: true,
    SUPPORT_CORS_XHR: true
};
//# sourceMappingURL=features.js.map
;
