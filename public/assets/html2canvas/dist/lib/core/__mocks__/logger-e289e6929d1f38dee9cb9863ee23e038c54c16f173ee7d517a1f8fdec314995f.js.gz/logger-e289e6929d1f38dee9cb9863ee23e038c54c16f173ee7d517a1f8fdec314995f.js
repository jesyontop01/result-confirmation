"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Logger = /** @class */ (function () {
    function Logger() {
    }
    Logger.prototype.debug = function () { };
    Logger.create = function () { };
    Logger.destroy = function () { };
    Logger.getInstance = function () {
        return logger;
    };
    Logger.prototype.info = function () { };
    Logger.prototype.error = function () { };
    return Logger;
}());
exports.Logger = Logger;
var logger = new Logger();
//# sourceMappingURL=/assets/html2canvas/dist/lib/core/__mocks__/logger.js-c53d9d3249f29314776c3dac858aaf0c3cad58956e85cf56163e4340d368abaa.map
//!

;
