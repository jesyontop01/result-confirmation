"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.contains = function (bit, value) { return (bit & value) !== 0; };
//# sourceMappingURL=bitwise.js.map
;
