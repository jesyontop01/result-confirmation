"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.contains = function (bit, value) { return (bit & value) !== 0; };
//# sourceMappingURL=/assets/html2canvas/dist/lib/core/bitwise.js-6394f1921e834fc341b885931898771d96b97f5f888a936b0e5491f3f2b4d7c7.map
//!

;
