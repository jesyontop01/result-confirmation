"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SMALL_IMAGE = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
//# sourceMappingURL=util.js.map
;
