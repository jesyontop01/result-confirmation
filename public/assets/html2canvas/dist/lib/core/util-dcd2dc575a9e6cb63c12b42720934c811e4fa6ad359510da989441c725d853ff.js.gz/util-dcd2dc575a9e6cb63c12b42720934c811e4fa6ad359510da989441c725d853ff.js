"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SMALL_IMAGE = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
//# sourceMappingURL=/assets/html2canvas/dist/lib/core/util.js-00f41440c254b45eba2f1b4ddc33c767cee93ce2ee9d876a82de96aaa45c9f4c.map
//!

;
