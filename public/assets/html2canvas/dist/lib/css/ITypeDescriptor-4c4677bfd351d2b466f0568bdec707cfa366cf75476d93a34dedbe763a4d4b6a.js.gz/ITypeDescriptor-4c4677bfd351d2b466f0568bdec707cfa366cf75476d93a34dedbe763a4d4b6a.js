"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=/assets/html2canvas/dist/lib/css/ITypeDescriptor.js-e5a28e7cb01346358da99a578fe37f52fc00e6d77652956bc86523a38d47c5ef.map
//!

;
