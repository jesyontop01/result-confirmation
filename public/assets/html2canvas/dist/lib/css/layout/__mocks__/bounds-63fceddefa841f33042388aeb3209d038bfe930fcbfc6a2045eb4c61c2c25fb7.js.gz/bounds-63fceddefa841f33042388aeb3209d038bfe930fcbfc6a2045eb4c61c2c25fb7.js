"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Bounds = jest.requireActual('../bounds').Bounds;
exports.parseBounds = function () {
    return new exports.Bounds(0, 0, 200, 50);
};
//# sourceMappingURL=bounds.js.map
;
