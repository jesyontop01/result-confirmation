"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Bounds = jest.requireActual('../bounds').Bounds;
exports.parseBounds = function () {
    return new exports.Bounds(0, 0, 200, 50);
};
//# sourceMappingURL=/assets/html2canvas/dist/lib/css/layout/__mocks__/bounds.js-d5fda562127bdf955b8c041f5cfa95b466ff902a05b2acd07608105706c106ff.map
//!

;
