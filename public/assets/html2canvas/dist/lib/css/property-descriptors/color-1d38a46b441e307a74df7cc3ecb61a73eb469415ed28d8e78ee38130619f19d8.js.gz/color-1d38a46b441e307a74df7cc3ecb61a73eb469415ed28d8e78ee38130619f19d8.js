"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var IPropertyDescriptor_1 = require("../IPropertyDescriptor");
exports.color = {
    name: "color",
    initialValue: 'transparent',
    prefix: false,
    type: IPropertyDescriptor_1.PropertyDescriptorParsingType.TYPE_VALUE,
    format: 'color'
};
//# sourceMappingURL=/assets/html2canvas/dist/lib/css/property-descriptors/color.js-69e13298d58b51222cd37441aee5ac82b5a13c557649da0242ca0a1bde7b7dbd.map
//!

;
