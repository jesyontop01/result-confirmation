"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=/assets/html2canvas/dist/lib/css/types/index.js-4ac80ac6cecca7fa9e1db58ce27dc86a11ca158dd24f130ba789f4bd09b95df1.map
//!

;
