"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var DocumentCloner = /** @class */ (function () {
    function DocumentCloner() {
        // eslint-disable-next-line @typescript-eslint/no-object-literal-type-assertion
        this.clonedReferenceElement = {};
    }
    DocumentCloner.prototype.toIFrame = function () {
        return Promise.resolve({});
    };
    DocumentCloner.destroy = function () {
        return true;
    };
    return DocumentCloner;
}());
exports.DocumentCloner = DocumentCloner;
//# sourceMappingURL=/assets/html2canvas/dist/lib/dom/__mocks__/document-cloner.js-0ad0fab909df1f423d214cb8a2b19baec7d9688d746d14d35ad3b8181df5811d.map
//!

;
