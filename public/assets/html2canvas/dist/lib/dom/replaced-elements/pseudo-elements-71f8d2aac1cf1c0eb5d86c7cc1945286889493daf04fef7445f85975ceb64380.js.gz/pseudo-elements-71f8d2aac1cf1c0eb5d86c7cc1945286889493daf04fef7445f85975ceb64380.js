//# sourceMappingURL=/assets/html2canvas/dist/lib/dom/replaced-elements/pseudo-elements.js-cabd580021ce3134a6e0d702031439685fc98e1f528c02545c27a0762e0b5ab9.map
//!

;
