"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.invariant = function (assertion, error) {
    if (!assertion) {
        console.error(error);
    }
};
//# sourceMappingURL=/assets/html2canvas/dist/lib/invariant.js-321c09c76e652fd4f3f692d90958ac5fbc0e9e283eb66987fe8c1c31eca522a9.map
//!

;
