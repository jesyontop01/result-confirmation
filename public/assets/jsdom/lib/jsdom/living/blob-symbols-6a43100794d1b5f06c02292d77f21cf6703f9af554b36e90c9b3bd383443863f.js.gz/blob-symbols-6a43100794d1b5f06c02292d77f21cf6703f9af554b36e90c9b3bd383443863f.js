"use strict";

exports.buffer = Symbol("buffer");
exports.type = Symbol("type");
exports.lastModified = Symbol("lastModified");
exports.closed = Symbol("closed");

