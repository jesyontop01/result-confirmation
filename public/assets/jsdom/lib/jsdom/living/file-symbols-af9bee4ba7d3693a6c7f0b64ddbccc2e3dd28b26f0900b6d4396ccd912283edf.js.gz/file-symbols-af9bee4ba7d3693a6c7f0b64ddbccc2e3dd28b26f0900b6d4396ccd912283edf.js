"use strict";

exports.name = Symbol("name");
