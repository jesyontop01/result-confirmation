"use strict";

exports.list = Symbol("list");
