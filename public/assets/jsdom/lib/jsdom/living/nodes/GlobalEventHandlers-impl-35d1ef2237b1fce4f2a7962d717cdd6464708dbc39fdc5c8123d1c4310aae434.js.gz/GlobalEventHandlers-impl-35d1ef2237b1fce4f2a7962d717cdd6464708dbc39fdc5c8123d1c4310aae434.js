"use strict";

class GlobalEventHandlersImpl { }

module.exports = {
  implementation: GlobalEventHandlersImpl
};
