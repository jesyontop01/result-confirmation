"use strict";

const HTMLElementImpl = require("./HTMLElement-impl").implementation;

class HTMLBRElementImpl extends HTMLElementImpl { }

module.exports = {
  implementation: HTMLBRElementImpl
};
