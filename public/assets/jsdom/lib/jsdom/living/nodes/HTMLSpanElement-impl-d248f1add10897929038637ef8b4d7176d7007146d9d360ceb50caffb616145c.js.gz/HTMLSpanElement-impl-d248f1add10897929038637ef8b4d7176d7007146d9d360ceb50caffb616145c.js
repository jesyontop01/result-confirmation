"use strict";

const HTMLElementImpl = require("./HTMLElement-impl").implementation;

class HTMLSpanElementImpl extends HTMLElementImpl { }

module.exports = {
  implementation: HTMLSpanElementImpl
};
