"use strict";

const HTMLElementImpl = require("./HTMLElement-impl").implementation;

class HTMLTableCaptionElementImpl extends HTMLElementImpl { }

module.exports = {
  implementation: HTMLTableCaptionElementImpl
};
