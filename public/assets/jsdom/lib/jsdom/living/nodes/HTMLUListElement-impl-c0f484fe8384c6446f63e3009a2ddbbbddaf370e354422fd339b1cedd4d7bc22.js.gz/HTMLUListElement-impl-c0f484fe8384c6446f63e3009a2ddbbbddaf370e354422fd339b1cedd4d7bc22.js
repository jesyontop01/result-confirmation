"use strict";

const HTMLElementImpl = require("./HTMLElement-impl").implementation;

class HTMLUListElementImpl extends HTMLElementImpl { }

module.exports = {
  implementation: HTMLUListElementImpl
};
