"use strict";

class NonElementParentNodeImpl {

}

module.exports = {
  implementation: NonElementParentNodeImpl
};
