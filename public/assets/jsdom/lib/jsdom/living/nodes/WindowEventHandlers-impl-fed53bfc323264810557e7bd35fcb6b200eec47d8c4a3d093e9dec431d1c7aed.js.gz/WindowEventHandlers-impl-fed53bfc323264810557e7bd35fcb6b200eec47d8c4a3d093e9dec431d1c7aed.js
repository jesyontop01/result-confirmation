"use strict";

class WindowEventHandlersImpl {

}

module.exports = {
  implementation: WindowEventHandlersImpl
};
