require('./').polyfill()
;
